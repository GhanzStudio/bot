# WA Bot Multi-Fungsi — Scaffold

Ini adalah **kerangka dasar** (bukan implementasi penuh) dari WhatsApp bot yang kamu spesifikasikan.
Sudah jalan dan siap dikembangkan; struktur dibuat modular supaya gampang menambah command baru.

## Yang sudah ada
- Koneksi Baileys multi-device + auto-reconnect + anti-crash dasar
- Command handler otomatis (drop file di `src/commands/<kategori>/`, langsung ke-load)
- Sistem owner / premium (dengan expired) / partner / sewa bot per grup
- Sistem limit harian untuk user non-premium
- Rate limiting / cooldown per command (anti-spam dasar)
- Database JSON sederhana (lowdb) — gampang diganti ke MongoDB/PostgreSQL/Firebase
- Command contoh yang **benar-benar jalan**: `.ping`, `.menu`, `.owner`, `.daftar`, `.qrcode`

## Yang belum diimplementasikan
Menu asli yang kamu kirim berisi 700+ command di puluhan kategori (tools, game, download,
search, sticker, AI, group management, RPG, dll). Itu terlalu besar untuk ditulis sekaligus —
kebanyakan juga butuh API key/endpoint pihak ketiga yang perlu kamu daftarkan sendiri
(misalnya untuk downloader TikTok/IG, AI chat, remini/HD, dll).

**Kategori yang sengaja tidak dibuatkan:** semua command NSFW dan kategori "asupan"/konten
serupa. Ini di luar apa yang bisa saya bantu buatkan, di percakapan manapun.

## Cara pakai
```bash
cp .env.example .env      # isi OWNER_NUMBERS dengan nomormu
npm install
npm start
```
Scan QR yang muncul di terminal pakai WhatsApp (Linked Devices).

## Cara menambah command baru
Buat file baru di `src/commands/<kategori>/nama-command.js`:
```js
module.exports = {
  name: 'halo',
  aliases: ['hi'],
  category: 'main',
  description: 'Contoh command',
  ownerOnly: false,
  premiumOnly: false,
  execute: async (sock, msg, args, ctx) => {
    await sock.sendMessage(ctx.jid, { text: 'Halo juga!' }, { quoted: msg });
  },
};
```
Tidak perlu didaftarkan di tempat lain — otomatis ter-load saat bot start.

## Langkah selanjutnya
Beri tahu kategori mana yang mau diprioritaskan (misalnya: downloader dulu, atau
group management dulu, atau AI dulu), supaya bisa dikerjakan bertahap dan fokus.
