// index.js
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const chalk = require('chalk');

const config = require('./src/config');
const { loadCommands, handleMessage } = require('./src/handler');

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState('./session');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: true,
    logger: pino({ level: 'silent' }),
    browser: [config.botName, 'Chrome', '1.0.0'],
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log(chalk.red('Koneksi terputus.'), 'Reconnect:', shouldReconnect);
      if (shouldReconnect) {
        startBot(); // auto-reconnect
      } else {
        console.log(chalk.red('Logged out. Hapus folder ./session lalu scan ulang QR.'));
      }
    } else if (connection === 'open') {
      console.log(chalk.green(`✅ ${config.botName} berhasil terhubung ke WhatsApp!`));
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;
    await handleMessage(sock, msg);
  });

  return sock;
}

loadCommands();
startBot().catch((err) => {
  console.error('Gagal start bot:', err);
  process.exit(1);
});

// Anti-crash: tangkap error yang tidak ke-handle supaya bot tidak mati total
process.on('uncaughtException', (err) => console.error('[uncaughtException]', err));
process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err));
