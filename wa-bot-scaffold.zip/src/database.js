// src/database.js
//
// Untuk scaffold ini dipakai JSON file DB (lowdb) supaya bisa langsung jalan
// tanpa setup server database dulu. Struktur data sudah dipisah rapi
// (users, groups, premium, partner, sewa) supaya nanti gampang dipindah
// ke MongoDB/PostgreSQL/Firebase tanpa mengubah cara command memanggilnya
// - cukup ganti isi file ini, command lain tidak perlu diubah.

const path = require('path');
const low = require('lowdb');
const FileSync = require('lowdb/FileSync');

const dbFile = path.join(__dirname, '..', 'database.json');
const adapter = new FileSync(dbFile);
const db = low(adapter);

db.defaults({
  users: {},   // { [jid]: { exp, koin, level, limit, terdaftar } }
  groups: {},  // { [groupId]: { welcome, goodbye, antilink, rules } }
  premium: {}, // { [jid]: { expiredAt } }
  partner: {}, // { [jid]: true }
  sewa: {},    // { [groupId]: { expiredAt } }
}).write();

function getUser(jid) {
  return db.get(`users.${jid}`).value();
}

function ensureUser(jid, config) {
  if (!getUser(jid)) {
    db.set(`users.${jid}`, {
      exp: 0,
      koin: 0,
      level: 1,
      limit: config.defaultLimit,
      terdaftar: false,
      createdAt: Date.now(),
    }).write();
  }
  return getUser(jid);
}

function updateUser(jid, patch) {
  db.set(`users.${jid}`, { ...getUser(jid), ...patch }).write();
}

function isPremium(jid) {
  const p = db.get(`premium.${jid}`).value();
  if (!p) return false;
  if (p.expiredAt && p.expiredAt < Date.now()) {
    db.unset(`premium.${jid}`).write();
    return false;
  }
  return true;
}

function setPremium(jid, days) {
  const expiredAt = Date.now() + days * 24 * 60 * 60 * 1000;
  db.set(`premium.${jid}`, { expiredAt }).write();
  return expiredAt;
}

function isPartner(jid) {
  return !!db.get(`partner.${jid}`).value();
}

function isSewaAktif(groupId) {
  const s = db.get(`sewa.${groupId}`).value();
  if (!s) return false;
  return s.expiredAt > Date.now();
}

module.exports = {
  db,
  getUser,
  ensureUser,
  updateUser,
  isPremium,
  setPremium,
  isPartner,
  isSewaAktif,
};
