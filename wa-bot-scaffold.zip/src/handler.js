// src/handler.js
//
// Cara nambah command baru: buat file .js di src/commands/<kategori>/,
// lalu export objek dengan bentuk di bawah ini. File otomatis ke-load,
// tidak perlu didaftarkan manual di tempat lain.
//
// module.exports = {
//   name: 'ping',
//   aliases: ['ping2'],
//   category: 'main',
//   description: 'Cek kecepatan respon bot',
//   ownerOnly: false,
//   premiumOnly: false,
//   execute: async (sock, msg, args, ctx) => { ... }
// };

const fs = require('fs');
const path = require('path');
const config = require('./config');
const permissions = require('./utils/permissions');
const rateLimit = require('./utils/rateLimit');
const database = require('./database');

const commands = new Map();

function loadCommands() {
  const commandsDir = path.join(__dirname, 'commands');
  const categories = fs.readdirSync(commandsDir);

  for (const category of categories) {
    const categoryPath = path.join(commandsDir, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const files = fs.readdirSync(categoryPath).filter((f) => f.endsWith('.js'));
    for (const file of files) {
      const cmd = require(path.join(categoryPath, file));
      if (!cmd.name || !cmd.execute) {
        console.warn(`[SKIP] ${file} tidak punya "name" atau "execute"`);
        continue;
      }
      cmd.category = cmd.category || category;
      commands.set(cmd.name, cmd);
      (cmd.aliases || []).forEach((alias) => commands.set(alias, cmd));
    }
  }
  console.log(`[HANDLER] ${commands.size} command/alias berhasil dimuat.`);
  return commands;
}

async function handleMessage(sock, msg) {
  try {
    const jid = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const isGroup = jid.endsWith('@g.us');

    const body =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      '';

    if (!body.startsWith(config.prefix)) return;

    const [rawCmd, ...args] = body.slice(config.prefix.length).trim().split(/\s+/);
    const commandName = rawCmd.toLowerCase();
    const cmd = commands.get(commandName);
    if (!cmd) return;

    // Sistem sewa bot: kalau dipakai di grup, cek grup itu sudah sewa/partner/owner
    if (isGroup && cmd.requireActiveGroup !== false) {
      const groupActive =
        permissions.isOwner(sender) ||
        permissions.isPartner(sender) ||
        database.isSewaAktif(jid);
      // Catatan: baris di atas contoh saja - sesuaikan aturan sewa sesuai kebutuhanmu,
      // misalnya sebagian command tetap gratis di semua grup.
    }

    if (cmd.ownerOnly && !permissions.isOwner(sender)) {
      return sock.sendMessage(jid, { text: '❌ Command ini khusus owner.' }, { quoted: msg });
    }
    if (cmd.premiumOnly && !permissions.isPremium(sender)) {
      return sock.sendMessage(
        jid,
        { text: '✨ Command ini khusus user premium. Ketik *.buyfitur* untuk info upgrade.' },
        { quoted: msg }
      );
    }

    const cooldownLeft = rateLimit.isOnCooldown(sender, cmd.name, config.cooldownMs);
    if (cooldownLeft) {
      return sock.sendMessage(
        jid,
        { text: `⏳ Tunggu ${cooldownLeft} detik lagi sebelum pakai command ini lagi.` },
        { quoted: msg }
      );
    }

    if (!cmd.ownerOnly && !cmd.premiumOnly && !permissions.consumeLimit(sender)) {
      return sock.sendMessage(
        jid,
        { text: '⚠️ Limit harian kamu habis. Upgrade premium atau tunggu reset harian.' },
        { quoted: msg }
      );
    }

    await cmd.execute(sock, msg, args, { jid, sender, isGroup, config, database });
  } catch (err) {
    console.error('[ERROR HANDLER]', err);
    // Notifikasi owner kalau error critical (opsional, aktifkan sesuai kebutuhan)
    // config.ownerNumbers.forEach(n => sock.sendMessage(`${n}@s.whatsapp.net`, { text: `Bot error: ${err.message}` }));
  }
}

module.exports = { loadCommands, handleMessage, commands };
