module.exports = {
  name: 'daftar',
  category: 'user',
  description: 'Mendaftarkan diri sebagai user bot',
  requireActiveGroup: false,
  execute: async (sock, msg, args, ctx) => {
    const user = ctx.database.ensureUser(ctx.sender, ctx.config);
    if (user.terdaftar) {
      return sock.sendMessage(ctx.jid, { text: 'Kamu sudah terdaftar ✅' }, { quoted: msg });
    }
    ctx.database.updateUser(ctx.sender, { terdaftar: true });
    await sock.sendMessage(
      ctx.jid,
      { text: `🎉 Berhasil daftar! Level: 1, Koin: 0, Limit harian: ${user.limit}` },
      { quoted: msg }
    );
  },
};
