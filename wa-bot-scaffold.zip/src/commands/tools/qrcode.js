const QRCode = require('qrcode');

module.exports = {
  name: 'qrcode',
  aliases: ['qr', 'txt2qr'],
  category: 'tools',
  description: 'Membuat QR code dari teks. Contoh: .qrcode Hello World',
  execute: async (sock, msg, args, ctx) => {
    const text = args.join(' ');
    if (!text) {
      return sock.sendMessage(ctx.jid, { text: 'Contoh: .qrcode Hello World' }, { quoted: msg });
    }
    const buffer = await QRCode.toBuffer(text, { width: 512 });
    await sock.sendMessage(
      ctx.jid,
      { image: buffer, caption: `QR code untuk: ${text}` },
      { quoted: msg }
    );
  },
};
