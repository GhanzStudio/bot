const config = require('../../config');

module.exports = {
  name: 'menu',
  aliases: ['allmenu', 'menucat'],
  category: 'main',
  description: 'Menampilkan menu utama bot',
  execute: async (sock, msg, args, ctx) => {
    const { commands } = require('../../handler');
    const categories = {};

    for (const cmd of new Set(commands.values())) {
      if (!categories[cmd.category]) categories[cmd.category] = [];
      if (!categories[cmd.category].includes(cmd.name)) categories[cmd.category].push(cmd.name);
    }

    let text = `👋 Halo! Ini menu *${config.botName}*\n\n`;
    for (const [cat, names] of Object.entries(categories)) {
      text += `📁 *${cat.toUpperCase()}*\n`;
      text += names.map((n) => `  ${config.prefix}${n}`).join('\n');
      text += '\n\n';
    }
    text += `Prefix: *${config.prefix}*\nContoh: *${config.prefix}ping*`;

    await sock.sendMessage(ctx.jid, { text }, { quoted: msg });
  },
};
