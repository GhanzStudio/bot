const config = require('../../config');

module.exports = {
  name: 'owner',
  category: 'main',
  description: 'Menampilkan kontak owner bot',
  execute: async (sock, msg, args, ctx) => {
    if (config.ownerNumbers.length === 0) {
      return sock.sendMessage(ctx.jid, { text: 'Owner belum diset di .env (OWNER_NUMBERS).' }, { quoted: msg });
    }
    const contacts = config.ownerNumbers.map((n) => ({
      displayName: config.botName + ' Owner',
      vcard:
        `BEGIN:VCARD\nVERSION:3.0\nFN:${config.botName} Owner\nTEL;type=CELL;type=VOICE;waid=${n}:+${n}\nEND:VCARD`,
    }));

    await sock.sendMessage(
      ctx.jid,
      { contacts: { displayName: 'Owner', contacts } },
      { quoted: msg }
    );
  },
};
