module.exports = {
  name: 'ping',
  aliases: ['ping2'],
  category: 'main',
  description: 'Cek kecepatan respon bot',
  execute: async (sock, msg, args, ctx) => {
    const start = Date.now();
    const sent = await sock.sendMessage(ctx.jid, { text: '🏓 Pong...' }, { quoted: msg });
    const latency = Date.now() - start;
    await sock.sendMessage(ctx.jid, { text: `🏓 Pong! ${latency}ms` });
  },
};
