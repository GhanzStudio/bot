// src/utils/rateLimit.js
// Cooldown sederhana di memori: mencegah user spam command yang sama
// terlalu cepat (anti-ban / anti-spam). Untuk deployment multi-proses,
// ganti Map ini dengan Redis.

const cooldowns = new Map();

function isOnCooldown(jid, commandName, cooldownMs) {
  const key = `${jid}:${commandName}`;
  const last = cooldowns.get(key);
  const now = Date.now();
  if (last && now - last < cooldownMs) {
    return Math.ceil((cooldownMs - (now - last)) / 1000); // sisa detik
  }
  cooldowns.set(key, now);
  return false;
}

module.exports = { isOnCooldown };
