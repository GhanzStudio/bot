// src/utils/permissions.js
const config = require('../config');
const database = require('../database');

function isOwner(jid) {
  const number = jid.split('@')[0];
  return config.ownerNumbers.includes(number);
}

function isPremium(jid) {
  return isOwner(jid) || database.isPremium(jid);
}

function isPartner(jid) {
  return isOwner(jid) || database.isPartner(jid);
}

// Cek & potong limit untuk user non-premium. Return true jika boleh lanjut.
function consumeLimit(jid) {
  if (isPremium(jid)) return true;
  const user = database.ensureUser(jid, config);
  if (user.limit <= 0) return false;
  database.updateUser(jid, { limit: user.limit - 1 });
  return true;
}

module.exports = { isOwner, isPremium, isPartner, consumeLimit };
