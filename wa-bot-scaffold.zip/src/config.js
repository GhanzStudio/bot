// src/config.js
// Semua konfigurasi bot dibaca dari .env supaya data sensitif tidak ikut ter-commit.
require('dotenv').config();

module.exports = {
  ownerNumbers: (process.env.OWNER_NUMBERS || '')
    .split(',')
    .map((n) => n.trim())
    .filter(Boolean),
  botName: process.env.BOT_NAME || 'BotSaya',
  prefix: process.env.PREFIX || '.',
  defaultLimit: parseInt(process.env.DEFAULT_LIMIT || '20', 10),
  cooldownMs: parseInt(process.env.COMMAND_COOLDOWN_MS || '3000', 10),
};
